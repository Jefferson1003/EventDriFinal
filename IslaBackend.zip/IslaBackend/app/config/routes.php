<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');
/**
 * ------------------------------------------------------------------
 * LavaLust - an opensource lightweight PHP MVC Framework
 * ------------------------------------------------------------------
 *
 * MIT License
 *
 * Copyright (c) 2020 Ronald M. Marasigan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package LavaLust
 * @author Ronald M. Marasigan <ronald.marasigan@yahoo.com>
 * @since Version 1
 * @link https://github.com/ronmarasigan/LavaLust
 * @license https://opensource.org/licenses/MIT MIT License
 */

/*
| -------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------
| Here is where you can register web routes for your application.
|
|
*/

// Welcome route
$router->get('/', 'Welcome::index');

// =============================================================================
// AUTH ROUTES - FIXED AND ORGANIZED
// =============================================================================

// Public Auth Routes (No authentication required)
$router->post('/auth/login', 'AuthController::login');
$router->post('/auth/register', 'AuthController::register');
$router->post('/auth/refresh', 'AuthController::refresh');
$router->post('/auth/fix-passwords', 'AuthController::fixPasswords'); // Utility route to fix passwords

// Protected Auth Routes (Require JWT authentication)
$router->post('/auth/logout', 'AuthController::logout');
$router->get('/auth/profile', 'AuthController::profile');

// =============================================================================
// API ROUTES (if needed for other controllers)
// =============================================================================

// Example protected API routes (uncomment if needed)
// $router->group('/api', function($router) {
//     // Users routes
//     $router->get('/users', 'UserController::index');
//     $router->get('/users/{id}', 'UserController::show');
//     $router->put('/users/{id}', 'UserController::update');
//     $router->delete('/users/{id}', 'UserController::delete');
    
//     // Products routes  
//     $router->get('/products', 'ProductController::index');
//     $router->post('/products', 'ProductController::store');
//     $router->get('/products/{id}', 'ProductController::show');
//     $router->put('/products/{id}', 'ProductController::update');
//     $router->delete('/products/{id}', 'ProductController::delete');
// });

// =============================================================================
// CATCH-ALL ROUTE FOR VUE.JS (if using Vue Router with history mode)
// =============================================================================

// This route should be last to catch all undefined routes and redirect to Vue app
$router->get('{any}', function() {
    // If you're using Vue.js with client-side routing, you can serve your main HTML file here
    // or return a 404 response for API routes
    
    // For API routes, return 404
    if (strpos($_SERVER['REQUEST_URI'], '/api/') === 0 || 
        strpos($_SERVER['REQUEST_URI'], '/auth/') === 0) {
        header('HTTP/1.1 404 Not Found');
        echo json_encode([
            'success' => false,
            'message' => 'Endpoint not found'
        ]);
        return;
    }
    
    // For frontend routes, serve your main Vue app HTML
    // readfile('path/to/your/vue/app/index.html');
    
    // Temporary response for undefined routes
    echo json_encode([
        'success' => false,
        'message' => 'Route not found',
        'available_routes' => [
            'POST /auth/login',
            'POST /auth/register', 
            'POST /auth/refresh',
            'POST /auth/logout',
            'GET /auth/profile',
            'POST /auth/fix-passwords'
        ]
    ]);
}, '.*'); // Match any route

// =============================================================================
// OPTIONAL: CORS HANDLING MIDDLEWARE (if needed)
// =============================================================================

// You can add CORS headers here if your frontend is on a different domain
header('Access-Control-Allow-Origin: http://localhost:3000'); // Adjust to your Vue app URL
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization, Accept');
header('Access-Control-Allow-Credentials: true');

// Handle preflight OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}