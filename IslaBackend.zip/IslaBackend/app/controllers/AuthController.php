<?php
class AuthController extends Controller {
    
    public function login() {
        try {
            $this->api->require_method('POST');
            $input = $this->api->body();
            
            $email = trim($input['email'] ?? '');
            $password = $input['password'] ?? '';

            // Input validation
            if (empty($email) || empty($password)) {
                $this->api->respond_error('Email and password are required', 400);
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $this->api->respond_error('Invalid email format', 400);
            }

            // Find user by email
            $stmt = $this->db->raw('SELECT * FROM users WHERE email = ?', [$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                $this->api->respond_error('Invalid email or password', 401);
            }

            // DEBUG: Check password verification
            error_log("Login attempt - Email: " . $email);
            error_log("Stored password hash: " . $user['password']);
            error_log("Stored password length: " . strlen($user['password']));
            error_log("Password verification result: " . (password_verify($password, $user['password']) ? 'SUCCESS' : 'FAILED'));

            if (password_verify($password, $user['password'])) {
                // Issue JWT tokens
                $tokens = $this->api->issue_tokens([
                    'id' => $user['id'], 
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'role' => $user['role']
                ]);
                
                $this->api->respond([
                    'success' => true,
                    'message' => 'Login successful',
                    'user' => [
                        'id' => $user['id'],
                        'name' => $user['name'],
                        'email' => $user['email'],
                        'role' => $user['role']
                    ],
                    'tokens' => $tokens
                ]);
            } else {
                $this->api->respond_error('Invalid email or password', 401);
            }
        } catch (Exception $e) {
            error_log('Login error: ' . $e->getMessage());
            $this->api->respond_error('Login failed. Please try again.', 500);
        }
    }

    public function register() {
        try {
            $this->api->require_method('POST');
            $input = $this->api->body();
           
            $name = trim($input['name'] ?? '');
            $email = trim($input['email'] ?? '');
            $password = $input['password'] ?? '';
            $password_confirmation = $input['password_confirmation'] ?? '';

            // Validation
            if (empty($name) || empty($email) || empty($password)) {
                $this->api->respond_error('All fields are required', 400);
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $this->api->respond_error('Invalid email format', 400);
            }

            if ($password !== $password_confirmation) {
                $this->api->respond_error('Passwords do not match', 400);
            }

            if (strlen($password) < 6) {
                $this->api->respond_error('Password must be at least 6 characters', 400);
            }

            // Check if email already exists
            $stmt = $this->db->raw('SELECT id FROM users WHERE email = ?', [$email]);
            if ($stmt->fetch()) {
                $this->api->respond_error('Email already exists', 400);
            }

            // FIXED: Enhanced password hashing with validation
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            
            if ($hashedPassword === false) {
                throw new Exception('Password hashing failed');
            }

            // DEBUG: Log the generated hash
            error_log("Generated password hash: " . $hashedPassword);
            error_log("Hash length: " . strlen($hashedPassword));

            // Check if password column can store the full hash
            if (strlen($hashedPassword) > 255) {
                throw new Exception('Password hash too long for database column');
            }

            // Create user with error handling
            $result = $this->db->raw(
                "INSERT INTO users (name, email, password, role, created_at) 
                 VALUES (?, ?, ?, 'user', NOW())",
                [$name, $email, $hashedPassword]
            );

            if (!$result) {
                throw new Exception('Database insertion failed');
            }

            $user_id = $this->db->get_connection()->lastInsertId();

            if (!$user_id) {
                throw new Exception('Failed to get user ID after insertion');
            }

            // Get created user
            $stmt = $this->db->raw('SELECT * FROM users WHERE id = ?', [$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                throw new Exception('Failed to retrieve created user');
            }

            // DEBUG: Verify stored password
            error_log("Stored password in DB: " . $user['password']);
            error_log("Stored password length: " . strlen($user['password']));
            error_log("Password verify test: " . (password_verify($password, $user['password']) ? 'SUCCESS' : 'FAILED'));

            // Issue tokens
            $tokens = $this->api->issue_tokens([
                'id' => $user['id'], 
                'name' => $user['name'],
                'email' => $user['email'],
                'role' => $user['role']
            ]);

            $this->api->respond([
                'success' => true,
                'message' => 'Registration successful',
                'user' => [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'role' => $user['role']
                ],
                'tokens' => $tokens
            ], 201);

        } catch (Exception $e) {
            error_log('Registration error: ' . $e->getMessage());
            $this->api->respond_error('Registration failed: ' . $e->getMessage(), 500);
        }
    }

    public function logout() {
        try {
            $this->api->require_method('POST');
            $input = $this->api->body();
            $refresh_token = $input['refresh_token'] ?? '';
            
            if (!empty($refresh_token)) {
                $this->api->revoke_refresh_token($refresh_token);
            }
            
            $this->api->respond([
                'success' => true,
                'message' => 'Logged out successfully'
            ]);
        } catch (Exception $e) {
            error_log('Logout error: ' . $e->getMessage());
            $this->api->respond_error('Logout failed', 500);
        }
    }

    public function profile() {
        try {
            $auth = $this->api->require_jwt();
            $user_id = $auth['sub'];
            
            $stmt = $this->db->raw(
                "SELECT id, name, email, role, created_at FROM users WHERE id = ?",
                [$user_id]
            );
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                $this->api->respond_error('User not found', 404);
            }
            
            $this->api->respond([
                'success' => true,
                'user' => $user
            ]);
        } catch (Exception $e) {
            error_log('Profile error: ' . $e->getMessage());
            $this->api->respond_error('Failed to fetch profile', 500);
        }
    }

    public function refresh() {
        try {
            $this->api->require_method('POST');
            $input = $this->api->body();
            $refresh_token = $input['refresh_token'] ?? '';
            
            if (empty($refresh_token)) {
                $this->api->respond_error('Refresh token required', 400);
            }
            
            $this->api->refresh_access_token($refresh_token);
        } catch (Exception $e) {
            error_log('Refresh error: ' . $e->getMessage());
            $this->api->respond_error('Token refresh failed', 500);
        }
    }

    /**
     * Utility method to fix existing users' passwords
     */
    public function fixPasswords() {
        try {
            $this->api->require_method('POST');
            $input = $this->api->body();
            $admin_password = $input['admin_password'] ?? '';
            
            // Simple admin check (you should implement proper admin authentication)
            if ($admin_password !== 'admin123') {
                $this->api->respond_error('Unauthorized', 401);
            }

            // Get all users with truncated passwords
            $stmt = $this->db->raw('SELECT id, email, password FROM users WHERE LENGTH(password) < 50');
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $fixed_count = 0;
            foreach ($users as $user) {
                // Set a default password for all fixed users
                $new_password = 'password123';
                $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
                
                $this->db->raw(
                    'UPDATE users SET password = ? WHERE id = ?',
                    [$hashed_password, $user['id']]
                );
                
                error_log("Fixed password for user: " . $user['email'] . " - New password: " . $new_password);
                $fixed_count++;
            }
            
            $this->api->respond([
                'success' => true,
                'message' => 'Fixed ' . $fixed_count . ' user passwords',
                'default_password' => 'password123'
            ]);
            
        } catch (Exception $e) {
            error_log('Fix passwords error: ' . $e->getMessage());
            $this->api->respond_error('Failed to fix passwords', 500);
        }
    }
}